# install.packages("shiny")
# install.packages("shinydashboard")
# install.packages("shinyBS")
# install.packages("shinyjs")
# install.packages("DT")
# install.packages("dashboardthemes")
# install.packages("shinycssloaders")
# install.packages("shinyWidgets")
# install.packages("wavelets")
# install.packages("ggplot2")
# install.packages("ppcor")
# install.packages("plotly")

library(shiny)
library(shinydashboard)
library(shinyBS)
library(shinyjs)
library(DT)
library(dashboardthemes)
library(shinycssloaders)
library(shinyWidgets)
library(wavelets)
library(ggplot2)
library(ppcor)
library(plotly)

toy_query_data <- read.csv("Query example.csv")
toy_library_data <- read.csv("Library example.csv")

##### Pre-processing(matrix transformation) #####
makelist <- function(data, st1 = " ", st2 = ":"){
  list <- data.frame(do.call(rbind,strsplit(strsplit(as.character(data),split = st1)[[1]],split = st2,fixed = TRUE)))
  list$X1 <- as.numeric(as.character(list$X1))
  list$X2 <- as.numeric(as.character(list$X2))
  list <- list[order(list$X1),]
  return(list)
}

makelists <- function(data){
  spectralist <- lapply(data,makelist)
  return(spectralist)
}

matrix_transforamtion <- function(data){
  spectralist <- makelists(data$spectra)
  n_obs <- length(spectralist)
  n_spec <- dim(spectralist[[1]])[1]
  mat <- matrix(0, n_obs, n_spec)
  for(i in 1:n_obs){
    mat[i,] <- spectralist[[i]]$X2
  }
  rownames(mat) <- data$cas
  colnames(mat) <- spectralist[[1]]$X1
  return(mat)
}

mz_transformation <- function(query_matrix, library_matrix){
  qmz <- ncol(query_matrix)
  lmz <- ncol(library_matrix)
  qn <- nrow(query_matrix)
  ln <- nrow(library_matrix)
  if(lmz > qmz){
    zeromat <- matrix(0, qn, lmz)
    zeromat[1:qn,1:qmz] <- query_matrix
    rownames(zeromat) <- c(1:qn)
    colnames(zeromat) <- c(1:lmz)
  }
  else if(lmz < qmz)
  {
    zeromat <- matrix(0, ln, qmz)
    zeromat[1:ln,1:lmz] <- library_matrix
    rownames(zeromat) <- rownames(library_matrix)
    colnames(zeromat) <- c(1:qmz)
  }
  return(zeromat)
}

##### Weighted spectra matrix #####
weighted_matrix <- function(mat, a = 0.5, b = 3){
  for(i in 1:nrow(mat)){
    mz_value <- as.numeric(ncol(mat))
    spectra <- as.numeric(mat[i,])
    weighted_spectra <- (spectra^a)*(mz_value^b)
    mat[i,] <- weighted_spectra
  }
  return(mat)
}

##### Cosine similarity #####
cosine_similarity <- function(query_matrix,library_matrix){
  library_matrix = library_matrix/sqrt(apply(library_matrix^2,1,sum))
  query_matrix = query_matrix/sqrt(apply(query_matrix^2,1,sum))
  cosine_matrix = query_matrix %*% t(library_matrix)
  # rownames(cosine_matrix) <- c(1:nrow(query_matrix))
  # colnames(cosine_matrix) <- rownames(library_matrix)
  return(cosine_matrix)
}

##### Stein and Scott's composite similarity#####
# SS similarity
ss_similarity <- function(query_matrix, library_matrix){
  ss_matrix <- matrix(0, nrow(query_matrix), nrow(library_matrix))
  for(i in 1:nrow(query_matrix)){
    for(j in 1:nrow(library_matrix)){
      ind_xy <- (query_matrix[i,] * library_matrix[j,]!=0) # X,Y ????��?? 0?? ?ƴ? ??
      N_xy <- sum(ind_xy) # 0?? ?ƴ? ???? ????
      if(N_xy<=1){
        ss_matrix[i,j] = 1;next
      } 
      result <- (query_matrix[i,][ind_xy][1:(N_xy-1)]/query_matrix[i,][ind_xy][2:N_xy])*
        (library_matrix[j,][ind_xy][2:N_xy]/library_matrix[j,][ind_xy][1:(N_xy-1)])
      ind_result <- result<=1 # ?հ? ???? ???? 1???? ??�� ?? -1��??
      result[ind_result] <- result[ind_result]^(-1)
      ss_matrix[i,j] <- sum(result)/N_xy
    }
  }
  rownames(ss_matrix) <- c(1:nrow(query_matrix))
  colnames(ss_matrix) <- rownames(library_matrix)
  return(ss_matrix)
}

##### Discrete Fourier- and wavelet- transform composite similarity#####
# Discrete Fourier- transformation
dft_matrix <- function(mat){
  fourier_mat <- t(Re(mvfft(t(mat))))
  return(fourier_mat)
}

# Discrete Wavelet- transformation
dwt_matrix <- function(mat){
  dwtmat <- dwt(t(mat), filter = "d4")
  w <- dwtmat@W$W1
  wavelet_mat <- matrix(w,nrow(mat),length(w)/nrow(mat))
  rownames(wavelet_mat) <- rownames(mat)
  return(wavelet_mat)
}

##### Semi-partial correlation #####
# Semi-partial correlation
# sp_similarity <- function(query_matrix, library_matrix, n){
#   c <- cosine_similarity(query_matrix, library_matrix)
#   qrank <- apply(c, 1, max)
#   idx <- which(qrank >= min(head(sort(qrank, decreasing = T), n)))
#   query_matrix <- query_matrix[idx,]
#   sp_matrix <- matrix(0, nrow(query_matrix), nrow(library_matrix))
#   for(i in 1:nrow(query_matrix)){
#     for(j in 1:nrow(library_matrix)){
#       sp_matrix[i,j] <- tryCatch(spcor.test(t(query_matrix)[,i],t(library_matrix)[,j],t(library_matrix)[,-j])$estimate,
#                                  error = function(e) 0)
#     }
#   }
#   rownames(sp_matrix) <- rownames(c)[idx]
#   colnames(sp_matrix) <- colnames(c)
#   return(sp_matrix)
# }

sp_similarity <- function(query_matrix, library_matrix, n){
  c <- cosine_similarity(query_matrix, library_matrix)
  sp_matrix <- matrix(0, nrow(query_matrix), nrow(library_matrix))
  for(i in 1:nrow(query_matrix)){
    rk <- head(order(abs(c[i,]), decreasing = T), n)
    for(j in 1:length(rk)){
      sp_matrix[i,rk[j]] <- tryCatch(spcor.test(t(query_matrix)[,i],t(library_matrix[rk,])[,j],t(library_matrix[rk,])[,-j])$estimate,
                                  error = function(e) 0)
      if(sp_matrix[i,rk[j]]>1){
        sp_matrix[i,rk[j]] <- 1
      } else if(sp_matrix[i,rk[j]] < -1) {sp_matrix[i,rk[j]] <- -1}
    }
  }
  rownames(sp_matrix) <- rownames(c)
  colnames(sp_matrix) <- colnames(c)
  return(sp_matrix)
}

##### 7. Composite similarity #####
# composite_similarity <- function(query_matrix, library_matrix, a = 0.5, b = 3, w = 0.1,
#                                  method = c("ss", "dft", "dwt","sp")){
#   compsite_matrix <- matrix(0, nrow(query_matrix), nrow(library_matrix))
#   for(i in 1:nrow(query_matrix)){
#     for(j in 1:nrow(library_matrix)){
#       ind_x <- (query_matrix[i,]!= 0)
#       N_x <- length(query_matrix[i,][ind_x])
#       ind_xy <- (query_matrix[i,] * library_matrix[j,]!=0)
#       N_xy <- length(query_matrix[i,][ind_xy])
#       if(method == "ss"){
#         compsite_matrix[i,j] <- (N_x*weighted_cosine_matrix[i,j]+N_xy*ss_matrix[i,j])/(N_x+N_xy)
#       } else if(method == "dft"){
#         compsite_matrix[i,j] <- (N_x*weighted_cosine_matrix[i,j]+N_xy*dft_cosine_matrix[i,j])/(N_x+N_xy)
#       } else if(method == "dwt"){
#         compsite_matrix[i,j] <- (N_x*weighted_cosine_matrix[i,j]+N_xy*dwt_cosine_matrix[i,j])/(N_x+N_xy)
#       } else if(method == "sp"){
#         compsite_matrix[i,j] <- (1-w)*weighted_cosine_matrix[i,j]+w*sp_matrix[i,j]
#       }
#     }
#   }
#   rownames(compsite_matrix) <- c(1:nrow(query_matrix))
#   colnames(compsite_matrix) <- rownames(library_matrix)
#   return(compsite_matrix)
# }

##### Top k matching algorithm #####
best_index <- function(similarity, topk = 3){
  lib_ind <- colnames(similarity)
  best <- matrix(0, nrow(similarity), topk)
  for(i in 1:nrow(similarity)){
    best_ind <- head(order(abs(similarity[i,]), decreasing = TRUE), topk)
    best[i,] <- lib_ind[best_ind]
  }
  colnames(best) <- sprintf("Top %d", 1:topk)
  rownames(best) <- rownames(similarity)
  return(best)
}

best_score <- function(similarity, topk = 3){
  best <- matrix(0, nrow(similarity), topk)
  for(i in 1:nrow(similarity)){
    best[i,] <- round(head(sort(abs(similarity[i,]), decreasing = TRUE), topk),7)
  }
  colnames(best) <- sprintf("Top %d", 1:topk)
  rownames(best) <- rownames(similarity)
  return(best)
}

best_location <- function(similarity, topk = 3){
  lib_ind <- colnames(similarity)
  best <- matrix(0, nrow(similarity), topk)
  for(i in 1:nrow(similarity)){
    best[i,] <- head(order(abs(similarity[i,]), decreasing = TRUE), topk)
  }
  colnames(best) <- sprintf("Top %d", 1:topk)
  rownames(best) <- rownames(similarity)
  return(best)
}