server <- function(input,output,session){
  
  update_all <- function(x) {
    updateSelectInput(session, "tab",
                      choices = c("", "Help", "Data load", "Settings", "Result"),
                      label = "",
                      selected = x
    )
  }
  
  observeEvent(input$help, {
    update_all("Help")
  })
  observeEvent(input$dataload, {
    update_all("Data load")
  })
  observeEvent(input$settings, {
    update_all("Settings")
  })
  observeEvent(input$result, {
    update_all("Result")
  })
  
  observeEvent("", {
    shinyjs::hide("tab")
  })
  
  observeEvent("", {
    shinyjs::show("page1")
    shinyjs::hide("page2")
    shinyjs::hide("page3")
    shinyjs::hide("page4")
  }, once = TRUE)
  observeEvent(input$help, {
    shinyjs::show("page1")
    shinyjs::hide("page2")
    shinyjs::hide("page3")
    shinyjs::hide("page4")
  })
  observeEvent(input$dataload, {
    shinyjs::show("page2")
    shinyjs::hide("page1")
    shinyjs::hide("page3")
    shinyjs::hide("page4")
  })
  observeEvent(input$settings, {
    shinyjs::show("page3")
    shinyjs::hide("page2")
    shinyjs::hide("page1")
    shinyjs::hide("page4")
  })
  observeEvent(input$result, {
    shinyjs::show("page4")
    shinyjs::hide("page2")
    shinyjs::hide("page3")
    shinyjs::hide("page1")
  })
  
  #####Help#####
  
  output$ui_help <- renderUI({
    fluidRow(
      column(8, offset = 1, h3("Help")),
      column(8, offset = 1, p("Metiden(tentative title) is a GC-MS metabolites identification tool.
                              Metabolites are identified with a matching algorithm using six similarities:
                              Cosine, Weighted Cosine, Stein & Scott, Discrete Fourier Transformation, Discrete Wavelet Transformation, and Semi-Partial Correlation.
                              The methodology for each similarity can be found in Reference.
                              Before starting the app, toy data is provided in the help menu of the sidebar, so it will be easy to understand how to use it.
                              A brief description of each sidebar's menus and tabs is provided. Detailed explanation: ppt hyperlink", style = "font-size:16px;")),
      column(8, offset = 1, h3("Data load")),
      column(8, offset = 1, p("You can load the GC-MS Metabolites query file and library file(if you have) required for identification.
                              If you do not have a query file, you can directly input one metabolite peak list and use it as query data.
                              If you do not have a library file, you can use the NIST Webbook and HMDB two libraries provided by the app.
                              In the sidebar menu, you can set the header and format of the loaded file.
                              The NIST WEBBOOK library was created with the date 04/13/2022.
                              As I said earlier, you can download toy_query.csv and toy_library.csv files and use them as example data.", style = "font-size:16px;")),
      column(8, offset = 1, h3("Settings")),
      column(8, offset = 1, p("In this tab, you can check the query data converted into a matrix to calculate the similarity, and show the intensity and m/z ratio through a bar graph. 
                              In the sidebar, there is a selection menu where you can select which query data graph to draw by entering a number, and there are two other menus.
                              The similarity menu has a radio button that allows you to calculate and determine the similarity to be used in the identification result.
                              In the parameter menu, it is possible to input a weight for calculating the weighted cosine similarity, to set the rank required for calculating the semi-partial correlation, and finally, to enter the Top k to determine the ranking of the matching result.", style = "font-size:16px;")),
      column(8, offset = 1, h3("Result")),
      column(8, offset = 1, p("In this tab, you can calculate the similarity according to the entered parameters and view the results.
                              You can see the query and library together through the comparison plot, and you can change the query and library by entering a number in the selection menu in the sidebar.
                              The similarity table and result table are determined according to the similarity selected in the similarity menu in the sidebar of settings, and the ranking of the result table can be changed through Top k of the parameter menu.", style = "font-size:16px;")),
      br(),
      column(8, offset = 1, h2("Reference")),
      column(8, offset = 1, p("Koo I, Zhang X, Kim S. Wavelet- and Fourier-transform-based spectrum similarity approaches to compound identification in gas chromatography/mass spectrometry. Anal Chem. 2011 Jul 15;83(14):5631-8. doi: ",
                              tags$a("10.1021/ac200740w.", href="https://doi.org/10.1021/ac200740w", target="_blank"), " Epub 2011 Jun 28. PMID: 21651237; PMCID: PMC3136582.")),
      column(8, offset = 1, p("Kim S, Koo I, Wei X, Zhang X. A method of finding optimal weight factors for compound identification in gas chromatography-mass spectrometry. Bioinformatics. 2012 Apr 15;28(8):1158-63. doi: ",
                              tags$a("10.1093/bioinformatics/bts083.", href="https://doi.org/10.1093/bioinformatics/bts083", target="_blank"), " Epub 2012 Feb 13. PMID: 22333245; PMCID: PMC3324511.")),
      column(8, offset = 1, p("Kim S, Koo I, Jeong J, Wu S, Shi X, Zhang X. Compound identification using partial and semipartial correlations for gas chromatography-mass spectrometry data. Anal Chem. 2012 Aug 7;84(15):6477-87. doi: ",
                              tags$a("10.1021/ac301350n.", href="https://doi.org/10.1021/ac301350n", target="_blank"), " Epub 2012 Jul 26. PMID: 22794294; PMCID: PMC3418476.")),
      column(8, offset = 1, p("Koo I, Kim S, Zhang X. Comparative analysis of mass spectral matching-based compound identification in gas chromatography-mass spectrometry. J Chromatogr A. 2013 Jul 12;1298:132-8. doi: ",
                              tags$a("10.1016/j.chroma.2013.05.021.", href="https://doi.org/10.1016/j.chroma.2013.05.021", target="_blank"), " Epub 2013 May 13. PMID: 23726352; PMCID: PMC3686837."))
    )
  })
  
  output$example_query <- downloadHandler(
    filename = function() {
      paste0("toy_query-", Sys.Date(), ".csv")
    },
    content = function(file) {
      write.csv(toy_query_data, file)
    }
  )
  
  output$example_library <- downloadHandler(
    filename = function() {
      paste0("toy_library-", Sys.Date(), ".csv")
    },
    content = function(file) {
      write.csv(toy_library_data, file)
    }
  )
  
  #####Data load#####
  
  # Query matrix & peak list
  query_matrix <- reactive({
    if(!is.null(input$query_file)){
      file1 <- input$query_file
      if(input$rb_queryform == ".csv"){
        que <- read.csv(file1$datapath, header = input$query_header)
      } else if(input$rb_queryform == ".txt"){
        que <- read.table(file1$datapath, header = input$query_header)
      } else {
        ext <- tools::file_ext(file1$datapath)
        req(file1)
        validate(need(ext == c("csv", "txt"), "Please upload a .csv or .txt file"))
      }
      que_mat <- matrix_transforamtion(que)
      rownames(que_mat) <- que$name
      return(que_mat)
    } else if(!is.null(input$peak_list)){
      ms <- makelist(input$peak_list, st1 = "\n", st2 = " ")
      zero_vector <- rep(0, ncol(library_matrix()))
      zero_vector[as.numeric(as.character(ms$X1))] <- as.numeric(as.character(ms$X2))
      mat <- matrix(zero_vector, 1)
      return(mat)
    }
  })
  
  # Library matrix
  library_matrix <- reactive({
    file2 <- input$library_file
    if(input$rb_libraryform == ".csv"){
      lib <- read.csv(file2$datapath, header = input$library_header)
    } else if(input$rb_libraryform == ".txt"){
      lib <- read.table(file2$datapath, header = input$library_header)
    } else {
      ext <- tools::file_ext(file2$datapath)
      req(file2)
      validate(need(ext == c("csv", "txt"), "Please upload a .csv or .txt file"))
    }
    lib_matrix <- matrix_transforamtion(lib)
    rownames(lib_matrix) <- lib$name
    return(lib_matrix)
  })
  
  # Similarity matrix
  cosine_matrix <- reactive(
    round(cosine_similarity(query_matrix(), library_matrix()),4)
  )
  weighted_cosine_matrix <- reactive(
    round(cosine_similarity(weighted_matrix(query_matrix(), a = input$weight_a, b = input$weight_b), weighted_matrix(library_matrix(), a = input$weight_a, b = input$weight_b)),4)
  )
  ss_matrix <- reactive(
    round(ss_similarity(query_matrix(), library_matrix()),4)
  )
  dft_cosine_matrix <- reactive(
    round(cosine_similarity(dft_matrix(query_matrix()), dft_matrix(library_matrix())),4)
  )
  dwt_cosine_matrix <- reactive(
    round(cosine_similarity(dwt_matrix(query_matrix()), dwt_matrix(library_matrix())),4)
  )
  sp_matrix <- reactive(
    round(sp_similarity(sp_rank(cosine_matrix(), query_matrix(), n = input$rank_n), library_matrix()), 4)
  )
  
  #####Settings#####
  
  # Query mass spectra plot
  output$ui_setting1 <- renderUI({
    tabBox(
      id = "box_ui_setting1",
      height = 500,
      width = "100%",
      tabPanel(
        title = "Query mass spectra",
        withSpinner(
          plotlyOutput(outputId = "plot_query"),
          type = 1
        )
      )
    )
  })
  
  plot_query <- reactive({
    queryplot_df <- data.frame(ity = weighted_matrix(query_matrix(), a = input$weight_a, b = input$weight_b)[input$ni_plot_query,], mz = c(1:ncol(query_matrix())))
    ggplot(queryplot_df, aes(mz, ity)) +
      geom_bar(stat = "identity", fill = "#0000FF") +
      scale_x_continuous("m/z ratio") +
      scale_y_continuous("Intensity", limits = c(0,10000)) +
      theme_bw()
  })
  
  output$plot_query <- renderPlotly({
    if (is.null(input$library_file)) {
      return(NULL)
    } else return(plot_query())
  })
  
  # View query data matrix
  output$ui_setting2 <- renderUI({
    tabBox(
      id = "box_ui_setting2",
      height = 500,
      width = "100%",
      tabPanel(
        title = "Query data matrix",
        withSpinner(
          DT::dataTableOutput("table_query"),
          type = 1
        )
      )
    )
  })
  
  output$table_query <- DT::renderDataTable({
    if (is.null(input$library_file)) {
      return(NULL)
    }
    datatable(
      weighted_matrix(query_matrix(), a = input$weight_a, b = input$weight_b),
      height = 500,
      width = "100%",
      extensions = "Buttons",
      options = list(
        buttons = c('csv', 'excel', 'pdf'),
        style = "bootstrap",
        scrollX = TRUE
      )
    )
  })
  
  #####Similarity#####
  
  # Cosine similarity
  output$sim1 <- DT::renderDataTable({
    if(is.null(input$library_file)){
      return(NULL)
    }
    datatable(
      round(cosine_matrix(),4),
      height = 400,
      width = "100%",
      extensions = "Buttons",
      options = list(
        dom = "Bfrtp",
        buttons = c('csv', 'excel', 'pdf'),
        style = "bootstrap",
        scrollX = TRUE
      )
    )
  })
  
  # Weighted cosine similarity
  output$sim2 <- DT::renderDataTable({
    if(is.null(input$library_file)){
      return(NULL)
    }
    datatable(
      round(weighted_cosine_matrix(),4),
      height = 400,
      width = "100%",
      extensions = "Buttons",
      options = list(
        dom = "Bfrtp",
        buttons = c('csv', 'excel', 'pdf'),
        style = "bootstrap",
        scrollX = TRUE
      )
    )
  })
  
  # Stein & Scott similarity
  output$sim3 <- DT::renderDataTable({
    if (is.null(input$library_file)) {
      return(NULL)
    }
    datatable(
      round(ss_matrix(),4),
      height = 400,
      width = "100%",
      extensions = "Buttons",
      options = list(
        dom = "Bfrtp",
        buttons = c('csv', 'excel', 'pdf'),
        style = "bootstrap",
        scrollX = TRUE
      )
    )
  })
  
  # DFT cosine similarity
  output$sim4 <- DT::renderDataTable({
    if (is.null(input$library_file)) {
      return(NULL)
    }
    datatable(
      round(dft_cosine_matrix(),4),
      height = 400,
      width = "100%",
      extensions = "Buttons",
      options = list(
        dom = "Bfrtp",
        buttons = c('csv', 'excel', 'pdf'),
        style = "bootstrap",
        scrollX = TRUE
      )
    )
  })
  
  # DWT cosine similarity
  output$sim5 <- DT::renderDataTable({
    if (is.null(input$library_file)) {
      return(NULL)
    }
    datatable(
      round(dwt_cosine_matrix(),4),
      height = 400,
      width = "100%",
      extensions = "Buttons",
      options = list(
        dom = "Bfrtp",
        buttons = c('csv', 'excel', 'pdf'),
        style = "bootstrap",
        scrollX = TRUE
      )
    )
  })
  
  # Semi-partial correlation
  output$sim6 <- DT::renderDataTable({
    if (is.null(input$library_file)) {
      return(NULL)
    }
    datatable(
      round(sp_matrix(),4),
      height = 400,
      width = "100%",
      extensions = "Buttons",
      options = list(
        dom = "Bfrtp",
        buttons = c('csv', 'excel', 'pdf'),
        style = "bootstrap",
        scrollX = TRUE
      )
    )
  })
  
  # Similarity tab
  output$table_similarity <- renderUI({
    
    out <- fluidRow(
      tabsetPanel(
        id = "tabsim",
        tabPanel("Cosine", DT::dataTableOutput("sim1")),
        tabPanel("Weighted cosine", DT::dataTableOutput("sim2"))
      )
    )
    
    if(input$rb_sim == 2){
      out <- fluidRow(
        tabsetPanel(
          id = "tabsim",
          tabPanel("Cosine", DT::dataTableOutput("sim1")),
          tabPanel("Weighted cosine", DT::dataTableOutput("sim2")),
          tabPanel("Stein & Scott", DT::dataTableOutput("sim3"))
        )
      )
    } else if(input$rb_sim == 3){
      out <- fluidRow(
        tabsetPanel(
          id = "tabsim",
          tabPanel("Cosine", DT::dataTableOutput("sim1")),
          tabPanel("Weighted cosine", DT::dataTableOutput("sim2")),
          tabPanel("Stein & Scott", DT::dataTableOutput("sim3")),
          tabPanel("DFT cosine", DT::dataTableOutput("sim4"))
        )
      )
    } else if(input$rb_sim == 4){
      out <- fluidRow(
        tabsetPanel(
          id = "tabsim",
          tabPanel("Cosine", DT::dataTableOutput("sim1")),
          tabPanel("Weighted cosine", DT::dataTableOutput("sim2")),
          tabPanel("Stein & Scott", DT::dataTableOutput("sim3")),
          tabPanel("DFT cosine", DT::dataTableOutput("sim4")),
          tabPanel("DWT cosine", DT::dataTableOutput("sim5"))
        )
      )
    } else if(input$rb_sim == 5){
      out <- fluidRow(
        tabsetPanel(
          id = "tabsim",
          tabPanel("Cosine", DT::dataTableOutput("sim1")),
          tabPanel("Weighted cosine", DT::dataTableOutput("sim2")),
          tabPanel("Stein & Scott", DT::dataTableOutput("sim3")),
          tabPanel("DFT cosine", DT::dataTableOutput("sim4")),
          tabPanel("DWT cosine", DT::dataTableOutput("sim5")),
          tabPanel("Semi-partial correlation", DT::dataTableOutput("sim6"))
        )
      )
    }
    return(out)
  })
  
  output$ui_similarity <- renderUI({
    tabBox(
      id = "ui_similarity",
      height = 400,
      width = "100%",
      tabPanel(
        title = "Similarity",
        withSpinner(
          uiOutput("table_similarity"),
          type = 1
        )
      )
    )
  })
  
  #####Result#####
  
  # Cosine result
  output$res1 <- DT::renderDataTable({
    if(is.null(input$library_file)){
      return(NULL)
    }
    bestindex <- best_index(cosine_matrix(), topk = input$top_k)
    colnames(bestindex) <- sprintf("Top %d", 1:input$top_k)
    rownames(bestindex) <- rownames(cosine_matrix())
    datatable(
      bestindex,
      height = 400,
      width = "100%",
      extensions = "Buttons",
      options = list(
        dom = "Bfrtp",
        buttons = c('csv', 'excel', 'pdf'),
        style = "bootstrap",
        scrollX = TRUE
      )
    )
  })
  
  # Weighted cosine result
  output$res2 <- DT::renderDataTable({
    if(is.null(input$library_file)){
      return(NULL)
    }
    bestindex <- best_index(weighted_cosine_matrix(), topk = input$top_k)
    colnames(bestindex) <- sprintf("Top %d", 1:input$top_k)
    rownames(bestindex) <- rownames(cosine_matrix())
    datatable(
      bestindex,
      height = 400,
      width = "100%",
      extensions = "Buttons",
      options = list(
        dom = "Bfrtp",
        buttons = c('csv', 'excel', 'pdf'),
        style = "bootstrap",
        scrollX = TRUE
      )
    )
  })
  
  # Stein & Scott result
  output$res3 <- DT::renderDataTable({
    if (is.null(input$library_file)) {
      return(NULL)
    }
    bestindex <- best_index(ss_matrix(), topk = input$top_k)
    colnames(bestindex) <- sprintf("Top %d", 1:input$top_k)
    rownames(bestindex) <- rownames(cosine_matrix())
    datatable(
      bestindex,
      height = 400,
      width = "100%",
      extensions = "Buttons",
      options = list(
        dom = "Bfrtp",
        buttons = c('csv', 'excel', 'pdf'),
        style = "bootstrap",
        scrollX = TRUE
      )
    )
  })
  
  # DFT result
  output$res4 <- DT::renderDataTable({
    if (is.null(input$library_file)) {
      return(NULL)
    }
    bestindex <- best_index(dft_cosine_matrix(), topk = input$top_k)
    colnames(bestindex) <- sprintf("Top %d", 1:input$top_k)
    rownames(bestindex) <- rownames(cosine_matrix())
    datatable(
      bestindex,
      height = 400,
      width = "100%",
      extensions = "Buttons",
      options = list(
        dom = "Bfrtp",
        buttons = c('csv', 'excel', 'pdf'),
        style = "bootstrap",
        scrollX = TRUE
      )
    )
  })
  
  # DWT result
  output$res5 <- DT::renderDataTable({
    if (is.null(input$library_file)) {
      return(NULL)
    }
    bestindex <- best_index(dwt_cosine_matrix(), topk = input$top_k)
    colnames(bestindex) <- sprintf("Top %d", 1:input$top_k)
    rownames(bestindex) <- rownames(cosine_matrix())
    datatable(
      bestindex,
      height = 400,
      width = "100%",
      extensions = "Buttons",
      options = list(
        dom = "Bfrtp",
        buttons = c('csv', 'excel', 'pdf'),
        style = "bootstrap",
        scrollX = TRUE
      )
    )
  })
  
  # Semi-partial result
  output$res6 <- DT::renderDataTable({
    if (is.null(input$library_file)) {
      return(NULL)
    }
    bestindex <- best_index(sp_matrix(), topk = input$top_k)
    colnames(bestindex) <- sprintf("Top %d", 1:input$top_k)
    rownames(bestindex) <- rownames(cosine_matrix())
    datatable(
      bestindex,
      height = 400,
      width = "100%",
      extensions = "Buttons",
      options = list(
        dom = "Bfrtp",
        buttons = c('csv', 'excel', 'pdf'),
        style = "bootstrap",
        scrollX = TRUE
      )
    )
  })
  
  # Result tab
  output$table_result <- renderUI({
    
    out <- fluidRow(
      tabsetPanel(
        id = "tabres",
        tabPanel("Cosine", DT::dataTableOutput("res1")),
        tabPanel("Weighted cosine", DT::dataTableOutput("res2"))
      )
    )
    
    if(input$rb_sim == 2){
      out <- fluidRow(
        tabsetPanel(
          id = "tabres",
          tabPanel("Cosine", DT::dataTableOutput("res1")),
          tabPanel("Weighted cosine", DT::dataTableOutput("res2")),
          tabPanel("Stein & Scott", DT::dataTableOutput("res3"))
        )
      )
    } else if(input$rb_sim == 3){
      out <- fluidRow(
        tabsetPanel(
          id = "tabres",
          tabPanel("Cosine", DT::dataTableOutput("res1")),
          tabPanel("Weighted cosine", DT::dataTableOutput("res2")),
          tabPanel("Stein & Scott", DT::dataTableOutput("res3")),
          tabPanel("DFT cosine", DT::dataTableOutput("res4"))
        )
      )
    } else if(input$rb_sim == 4){
      out <- fluidRow(
        tabsetPanel(
          id = "tabres",
          tabPanel("Cosine", DT::dataTableOutput("res1")),
          tabPanel("Weighted cosine", DT::dataTableOutput("res2")),
          tabPanel("Stein & Scott", DT::dataTableOutput("res3")),
          tabPanel("DFT cosine", DT::dataTableOutput("res4")),
          tabPanel("DWT cosine", DT::dataTableOutput("res5"))
        )
      )
    } else if(input$rb_sim == 5){
      out <- fluidRow(
        tabsetPanel(
          id = "tabres",
          tabPanel("Cosine", DT::dataTableOutput("res1")),
          tabPanel("Weighted cosine", DT::dataTableOutput("res2")),
          tabPanel("Stein & Scott", DT::dataTableOutput("res3")),
          tabPanel("DFT cosine", DT::dataTableOutput("res4")),
          tabPanel("DWT cosine", DT::dataTableOutput("res5")),
          tabPanel("Semi-partial correlation", DT::dataTableOutput("res6"))
        )
      )
    }
    
    return(out)
  })
  
  output$ui_result2 <- renderUI({
    tabBox(
      id = "box_ui_result2",
      height = 400,
      width = "100%",
      tabPanel(
        title = "Identification result",
        withSpinner(
          uiOutput("table_result"),
          type = 1
        )
      )
    )
  })
  
  # Comparison plot(query & library)
  output$ui_result1 <- renderUI({
    tabBox(
      id = "box_ui_result1",
      height = 500,
      width = "100%",
      tabPanel(
        title = "Result plot(query & library mass spectra)",
        withSpinner(
          plotlyOutput(outputId = "plot_result"),
          type = 1
        )
      )
    )
  })
  
  plot_result <- reactive({
    resultplot_df <- data.frame(ity=c(query_matrix()[input$ni_plot_result1,], -library_matrix()[input$ni_plot_result2,]),
                                NAME = factor(rep(c(input$ni_plot_result1, rownames(library_matrix())[input$ni_plot_result2]), each = ncol(query_matrix()))), mz = c(1:ncol(query_matrix())))
    ggplot(resultplot_df, aes(mz, ity, fill = NAME)) +
      geom_bar(stat = "identity") +
      scale_x_continuous("m/z ratio") +
      scale_y_continuous("intensity", limits = c(-10000,10000), labels = abs) +
      scale_fill_manual(values=c("#0000FF","#FF0000"), guide = "none") +
      geom_hline(aes(yintercept = 0)) +
      theme_bw()
  })
  
  output$plot_result <- renderPlotly({
    if (is.null(input$library_file)) { 
      return(NULL)
    } else return(plot_result())
  })
}