ui <- dashboardPage(
  title = "Metiden",
  skin = "green",
  
  #####HEADER#####
  
  dashboardHeader(
    title = "Metiden",
    dropdownMenu(
      type = "notifications", 
      headerText = strong("INFO"), 
      icon = icon("info"), 
      badgeStatus = NULL,
      notificationItem(
        text = "Manual & Reference",
        icon = icon("user-circle")
      ),
      notificationItem(
        text = "Load a file, Spectra typing and Select a library",
        icon = icon("database")
      ),
      notificationItem(
        text = "Data description for the parameter selection",
        icon = icon("cogs")
      ),
      notificationItem(
        text = "The identification result table and the similarity table.",
        icon = icon("thumbs-up")
      )
    )
  ),
  
  #####SIDEBAR#####
  
  dashboardSidebar(
    width = 320,
    div(class = "inlay", style = "height:15px; width:100%; background-color: #eeeeee;"),
    menuItem(
      "HELP",
      tabName = "help",
      icon = icon("user-circle"),
      menuItem(
        "DOWNLOAD SELECTION",
        tabName = "download",
        icon = icon("download"),
        downloadButton(
          outputId = "example_query",
          label = "Download toy query",
          icon = icon("download")
        ),
        downloadButton(
          outputId = "example_library",
          label = "Download toy library",
          icon = icon("download")
        )
      )
    ),
    br(),
    br(),
    menuItem(
      "DATA LOAD",
      tabName = "dataload",
      icon = icon("database"),
      menuItem(
        "INPUT QUERY",
        tabName = "inputquery",
        checkboxInput(
          inputId = "query_header", label = "Query header", value = TRUE
        ),
        radioButtons(
          inputId = "rb_queryform", label = "Query format", choices = c(".csv", ".txt")
        )
      ),
      menuItem(
        "INPUT LIBRARY",
        tabName = "inputlibrary",
        checkboxInput(
          inputId = "library_header", label = "Library header", value = TRUE
        ),
        radioButtons(
          inputId = "rb_libraryform", label = "Library format", choices = c(".csv", ".txt")
        )
      )
    ),
    br(),
    br(),
    menuItem(
      "SETTINGS",
      tabName = "settings",
      icon = icon("cogs"),
      numericInput(
        inputId = "ni_plot_query", label = "Select query index", value = 1
      ),
      menuItem(
        "PARAMETER",
        tabName = "factor",
        numericInput(
          inputId = "weight_a", label = h4("Weight a"), value = 1
        ),
        numericInput(
          inputId = "weight_b", label = h4("Weight b"), value = 0
        ),
        numericInput(
          inputId = "rank_n", label = h4("Rank"), value = 10
        ),
        numericInput(
          inputId = "top_k", label = h4("Top k"), value = 3
        )
      ),
      menuItem(
        "SIMILARITY",
        tabName = "similarity",
        radioButtons(
          inputId = "rb_sim", label = "Choose similarity",
          choices = list("Weighted cosine similarity" = "1", "Stein & Scott similarity" = "2", "Discrete Fourier transforamtion" = "3", 
                         "Discrete wavelet transforamtion" = "4", "Semi-partial correlation" = "5"),
          selected = NULL
        )
      )
    ),
    br(),
    br(),
    menuItem(
      "RESULT",
      tabName = "result",
      icon = icon("thumbs-up"),
      numericInput(
        inputId = "ni_plot_result1", label = "Select query for plot", value = 1
      ),
      numericInput(
        inputId = "ni_plot_result2", label = "Select library for plot", value = 1
      )
    )
  ),
  
  #####BODY#####
  
  dashboardBody(
    tags$head(
      tags$style(
        HTML(
          ".navbar-nav > .messages-menu > .dropdown-menu, .navbar-nav > .notifications-menu > .dropdown-menu, .navbar-nav > .tasks-menu > .dropdown-menu {
            width: 400px;
            box-shadow: 5px 5px 5px darkgrey;
          }
          
          .navbar-nav > .notifications-menu > .dropdown-menu > li .menu > li > a {
            color: #000000;
            overflow: hidden;
            white-space: normal;
          }"
        )
      )
    ),
    useShinyjs(),
    fluidRow(
      column(
        width = 12,
        bsButton(
          inputId = "help", 
          label = "HELP", 
          icon = icon("user-circle"), 
          style = "success"
        ),
        bsButton(
          inputId = "dataload", 
          label = "DATA LOAD", 
          icon = icon("database"), 
          style = "success"
        ),
        bsButton(
          inputId = "settings", 
          label = "SETTINGS", 
          icon = icon("cogs"), 
          style = "success"
        ),
        bsButton(
          inputId = "result", 
          label = "RESULT", 
          icon = icon("thumbs-up"), 
          style = "success"
        )
      )
    ),
    fluidRow(
      div(
        id = "page1",
        column(
          12,
          uiOutput("ui_help")
        )
      )
    ),
    fluidRow(
      div(
        id = "page2",
        column(
          6, h3("Load query data"),br(),
          fileInput(inputId = "query_file", label = "Browse(query data)", accept = c(".txt", ".csv"), width = 500),
          textAreaInput(inputId = "peak_list", label = "GC/MS Peak list", width = 500, rows = 10, placeholder = "Enter one mass (m/z) and intensity corresponding to one peak per line."),
          align = "center"
        ),
        column(
          6, h3("Load library data"),br(),
          fileInput(inputId = "library_file", label = "Browse(library data)", accept = c(".txt", ".csv"), width = 500),
          selectInput(inputId = "library", label = "Choose library", choices = c("None", "NIST Webbok", "HMDB")),
          align = "center"
        )
      )
    ),
    fluidRow(
      div(
        id = "page3",
        br(),
        column(
          6,
          uiOutput("ui_setting1")
        ),
        column(
          6,
          uiOutput("ui_setting2")
        )
      )
    ),
    fluidRow(
      div(
        id = "page4",
        br(),
        column(
          12,
          uiOutput("ui_result1")
        ),
        column(
          6,
          uiOutput("ui_result2")
        ),
        column(
          6,
          uiOutput("ui_similarity")
        )
      )
    )
  )
)